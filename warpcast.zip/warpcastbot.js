const fetch = require('node-fetch');
const readlineSync = require('readline-sync');
const chalk = require('chalk');
const fs = require('fs');
const {
    table
} = require('table');
const path = require('path');
var configData = fs.readFileSync(`loginWarpcast.json`);
var config = JSON.parse(configData)
const detect = config;
var delay = require('delay')

function checkCastChannel(cookie, usernamechannel) {
    const index = fetch('https://client.warpcast.com/v2/feed-items', {
            method: 'POST',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Amplitude-Device-Id': 'FuT4wwVGaKuYsCtAKb57WD',
                'Fc-Amplitude-Session-Id': '1710780495943',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'feedKey': usernamechannel,
                'feedType': 'default',
                'viewedCastHashes': '',
                'updateState': true
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function followCaster(cookie, usernamecastgroup) {
    const index = fetch('https://client.warpcast.com/v2/feed-follows', {
            method: 'PUT',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Amplitude-Device-Id': 'FuT4wwVGaKuYsCtAKb57WD',
                'Fc-Amplitude-Session-Id': '1710780495943',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'feedKey': usernamecastgroup
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function checkChannelCaster(cookie) {
    const index = fetch('https://client.warpcast.com/v2/discover-channels?limit=100', {
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Amplitude-Device-Id': 'FuT4wwVGaKuYsCtAKb57WD',
                'Fc-Amplitude-Session-Id': '1710780495943',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function checkCastTarget(cookie, username, txhash) {
    const index = fetch('https://client.warpcast.com/v2/user-thread-casts?castHashPrefix=' + txhash + '&username=' + username + '&limit=1', {
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Amplitude-Device-Id': 'FuT4wwVGaKuYsCtAKb57WD',
                'Fc-Amplitude-Session-Id': '1710780495943',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function checkCast2(cookie, userid) {
    const index = fetch('https://client.warpcast.com/v2/profile-casts?fid=' + userid + '&limit=99', {
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Amplitude-Device-Id': 'FuT4wwVGaKuYsCtAKb57WD',
                'Fc-Amplitude-Session-Id': '1710770828056',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'If-None-Match': 'W/"WbBpzssRNVXGFWswHD45jdS86j0="',
                'Te': 'trailers'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}


function checkCast(cookie) {
    const index = fetch('https://client.warpcast.com/v2/search-casts?q=comment%20%26%20degen&limit=99', {
            headers: {
                'Host': 'client.warpcast.com',
                'Content-Type': 'application/json; charset=utf-8',
                'Fc-Address': '0xAF5e4745714Fc925F1F563D719d3D9A32976aC46',
                'Fc-Amplitude-Device-Id': 'be9460eb-e018-452e-9775-1e69fb58bbf5',
                'Fc-Native-Build-Version': '374',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Device-Os': 'iOS',
                'Accept-Language': 'id-ID,id;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Fc-Native-Application-Version': '1.0.70',
                'If-None-Match': 'W/"lVoz3SWLJ6N5ZzV0WO7ezjLUThg="',
                'Fc-Device-Model': 'iPhone16,2',
                'User-Agent': 'mobile-client/374 CFNetwork/1490.0.4 Darwin/23.2.0',
                'Fc-Amplitude-Session-Id': '1707244307702'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function checkFollowingCursor(cookie, userId, cursor) {
    const index = fetch('https://client.warpcast.com/v2/following?cursor=' + cursor + '&fid=' + userId + '&limit=500', {
            headers: {
                'Host': 'client.warpcast.com',
                'Content-Type': 'application/json; charset=utf-8',
                'Fc-Address': '0xAF5e4745714Fc925F1F563D719d3D9A32976aC46',
                'Fc-Amplitude-Device-Id': 'be9460eb-e018-452e-9775-1e69fb58bbf5',
                'Fc-Native-Build-Version': '374',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Device-Os': 'iOS',
                'Accept-Language': 'id-ID,id;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Fc-Native-Application-Version': '1.0.70',
                'If-None-Match': 'W/"lVoz3SWLJ6N5ZzV0WO7ezjLUThg="',
                'Fc-Device-Model': 'iPhone16,2',
                'User-Agent': 'mobile-client/374 CFNetwork/1490.0.4 Darwin/23.2.0',
                'Fc-Amplitude-Session-Id': '1707244307702'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function checkFollowing(cookie, userId) {
    const index = fetch('https://client.warpcast.com/v2/following?fid=' + userId + '&limit=500', {
            headers: {
                'Host': 'client.warpcast.com',
                'Content-Type': 'application/json; charset=utf-8',
                'Fc-Address': '0xAF5e4745714Fc925F1F563D719d3D9A32976aC46',
                'Fc-Amplitude-Device-Id': 'be9460eb-e018-452e-9775-1e69fb58bbf5',
                'Fc-Native-Build-Version': '374',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Device-Os': 'iOS',
                'Accept-Language': 'id-ID,id;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Fc-Native-Application-Version': '1.0.70',
                'If-None-Match': 'W/"lVoz3SWLJ6N5ZzV0WO7ezjLUThg="',
                'Fc-Device-Model': 'iPhone16,2',
                'User-Agent': 'mobile-client/374 CFNetwork/1490.0.4 Darwin/23.2.0',
                'Fc-Amplitude-Session-Id': '1707244307702'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function profile(cookie) {
    const index = fetch('https://client.warpcast.com/v2/onboarding-state', {
            headers: {
                'Host': 'client.warpcast.com',
                'Content-Type': 'application/json; charset=utf-8',
                'Fc-Address': '0xAF5e4745714Fc925F1F563D719d3D9A32976aC46',
                'Fc-Amplitude-Device-Id': 'be9460eb-e018-452e-9775-1e69fb58bbf5',
                'Fc-Native-Build-Version': '374',
                'Authorization': 'Bearer ' + cookie + '',
                'Fc-Device-Os': 'iOS',
                'Accept-Language': 'id-ID,id;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Fc-Native-Application-Version': '1.0.70',
                'If-None-Match': 'W/"lVoz3SWLJ6N5ZzV0WO7ezjLUThg="',
                'Fc-Device-Model': 'iPhone16,2',
                'User-Agent': 'mobile-client/374 CFNetwork/1490.0.4 Darwin/23.2.0',
                'Fc-Amplitude-Session-Id': '1707244307702'
            }
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function checkingUsername(username) {
    const index = fetch('https://warpcast.com/' + username + '', {
            headers: {
                'Host': 'warpcast.com',
                'Accept': '*/*',
                'Range': 'bytes=0-99999',
                'User-Agent': 'WhatsApp/2.24.2.75 i',
                'Accept-Language': 'id-ID,id;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br'
            }
        })

        .then(async res => {
            const data = await res.text()
            return data
        })
    return index
}

function unFollow(cookie, userId) {
    const index = fetch('https://client.warpcast.com/v2/follows', {
            method: 'DELETE',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                //   'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                //   'Fc-Amplitude-Device-Id': 'rRm8c8fwah4ocLcbO3Q-Ib',
                //   'Fc-Amplitude-Session-Id': '1707243698824',
                //   'Content-Length': '20',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'targetFid': parseInt(userId)
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function follow(cookie, userId) {
    const index = fetch('https://client.warpcast.com/v2/follows', {
            method: 'PUT',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                //   'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                //   'Fc-Amplitude-Device-Id': 'rRm8c8fwah4ocLcbO3Q-Ib',
                //   'Fc-Amplitude-Session-Id': '1707243698824',
                //   'Content-Length': '20',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'targetFid': parseInt(userId)
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function likes(cookie, threadHash) {
    const index = fetch('https://client.warpcast.com/v2/cast-likes', {
            method: 'PUT',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                //   'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                //   'Fc-Amplitude-Device-Id': 'rRm8c8fwah4ocLcbO3Q-Ib',
                //   'Fc-Amplitude-Session-Id': '1707243698824',
                //   'Content-Length': '20',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'castHash': threadHash
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function recasts(cookie, threadHash) {
    const index = fetch('https://client.warpcast.com/v2/recasts', {
            method: 'PUT',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                //   'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                //   'Fc-Amplitude-Device-Id': 'rRm8c8fwah4ocLcbO3Q-Ib',
                //   'Fc-Amplitude-Session-Id': '1707243698824',
                //   'Content-Length': '20',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'castHash': threadHash
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function commentBro(cookie, threadHash, Comment) {
    const index = fetch('https://client.warpcast.com/v2/casts', {
            method: 'POST',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                //   'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                //   'Fc-Amplitude-Device-Id': 'rRm8c8fwah4ocLcbO3Q-Ib',
                //   'Fc-Amplitude-Session-Id': '1707243698824',
                //   'Content-Length': '20',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'text': Comment,
                'parent': {
                    'hash': threadHash
                },
                'embeds': [],
                'channelKey': 'farcaster'
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

function mintingBro(cookie, threadHash, framePost) {
    const index = fetch('https://client.warpcast.com/v2/cast-frame-action', {
            method: 'POST',
            headers: {
                'Host': 'client.warpcast.com',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
                'Accept': '*/*',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                //   'Accept-Encoding': 'gzip, deflate, br',
                'Referer': 'https://warpcast.com/',
                'Content-Type': 'application/json; charset=utf-8',
                'Authorization': 'Bearer ' + cookie + '',
                //   'Fc-Amplitude-Device-Id': 'rRm8c8fwah4ocLcbO3Q-Ib',
                //   'Fc-Amplitude-Session-Id': '1707243698824',
                //   'Content-Length': '20',
                'Origin': 'https://warpcast.com',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-site',
                'Te': 'trailers'
            },
            body: JSON.stringify({
                'castHash': threadHash,
                'framePostUrl': framePost,
                'frameActionIndex': 1
            })
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return index
}

(async () => {
    // while (true) {

    //     const filePath = path.join(__dirname, 'license.txt');
    //     if (fs.existsSync(filePath)) {} else {
    //         var apiKey = readlineSync.question("[+] Input License : ")
    //         fs.appendFileSync(filePath, apiKey);
    //     }

    //     var license = fs.readFileSync(`license.txt`, 'UTF-8');
    //     const licenseCheckResult = await licenseCheck(license);
    //     const namaBuyer = licenseCheckResult.FullName;
    //     const duration = licenseCheckResult.Duration;
    //     const MachineId1 = licenseCheckResult.MachineId1;
    //     const MachineId2 = licenseCheckResult.MachineId2;
    //     const MachineId3 = licenseCheckResult.MachineId3;
    //     const MachineId4 = licenseCheckResult.MachineId4;
    //     const MachineId5 = licenseCheckResult.MachineId5;
    //     const MachineId6 = licenseCheckResult.MachineId6;
    //     const MachineId7 = licenseCheckResult.MachineId7;
    //     const MachineId8 = licenseCheckResult.MachineId8;
    //     const MachineId9 = licenseCheckResult.MachineId9;
    //     const MachineId10 = licenseCheckResult.MachineId10;
    //     let id = machineIdSync;
    //     let myId = await id.machineSync({
    //         original: true
    //     });
    //     console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Machine Id :`, chalk.yellow(`${myId}`))
    //     if (namaBuyer) {
    //         console.log(chalk.white(`\nHas Found License`), chalk.green(`${namaBuyer}`), chalk.white(`Duration : `) + chalk.yellow(`${duration} Days\n`));
    //     } else {
    //         console.log(chalk.white(`\nNot Found License\n`));
    //         console.log(err)
    //         process.exit(0)
    //     }
    //     var data = `${MachineId1},${MachineId2}`;

    //     if (data.match(myId)) {} else {
    //         console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Not Found Machine ID On License :`, chalk.yellow(`${myId}`))
    //     }

    //     if (MachineId1 == '') {
    //         const addMachinez = await addMachine1(license, myId);
    //         console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Successfully Added Machine ID 1 :`, chalk.yellow(`${myId}`))
    //         continue;
    //     } else if (MachineId1 == myId) {
    //         console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Found Machine ID 1 :`, chalk.yellow(`${MachineId1}`))
    //         break;
    //     }

    //     if (MachineId2 == '') {
    //         const addMachinez = await addMachine2(license, myId);
    //         console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Successfully Added Machine ID 2 :`, chalk.yellow(`${myId}`))
    //         continue;
    //     } else if (MachineId2 == myId) {
    //         console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Found Machine ID 2 :`, chalk.yellow(`${MachineId2}`))
    //         break;
    //     }
    // }

    console.log(chalk.yellow(`    Membership x ETL Discussion\n`))


    console.log(`    List Account Login`)
    console.log()
    var configData = fs.readFileSync(`loginWarpcast.json`);
    var config = JSON.parse(configData)
    const detect = config;
    const totalAccount = config.length;
    let tableData = [
        ['id', 'Username', 'Email', 'Verified Account', 'User ID']
    ];
    const configTable = {
        columns: [{
            alignment: 'center'
        }, {
            alignment: 'center'
        }, {
            alignment: 'center'
        }, {
            alignment: 'center'
        }]
    };

    for (let index = 0; index < totalAccount; index++) {
        const cookie = detect[index].cookieAccount;
        const profileCheck = await profile(cookie);
        try {
            var username = profileCheck.result.state.user.username;
            var email = profileCheck.result.state.email;
            var verified = profileCheck.result.state.user.pfp.verified;
            var userId = profileCheck.result.state.user.fid;
        } catch (err) {
            console.log(err)
            var username = "Account Not Login";
            var email = "Account Not Login";
            var verified = "Account Not Login";
            var userId = "Account Not Login";
        }

        tableData.push([index, chalk.green(username), email, verified, chalk.yellow(userId)])
    }
    console.log(table(tableData, configTable))

    console.log('[1] ' + chalk.green('Warpcast Input Cookie'))
    console.log('[2] ' + chalk.green('Warpcast Delete Cookie'))
    console.log('[3] ' + chalk.green('Warpcast Getting FID'))
    console.log('[4] ' + chalk.green('Warpcast Follow Following Target'))
    console.log('[5] ' + chalk.green('Warpcast Mass Unfollow'))
    console.log('[6] ' + chalk.green('Warpcast Like & Recast & Follow & Comment & Mint By Search'))
    console.log('[7] ' + chalk.green('Warpcast Unfollow if not follow'))
    console.log('[8] ' + chalk.green('Warpcast Like / Recast with username / url'))
    console.log('[9] ' + chalk.green('Warpcast Auto follow all channel [ max 100 ]'))
    console.log('[10] ' + chalk.green('Warpcast Like & Recast & Follow By Target Channel'))

    console.log()
    var pilihan = readlineSync.question('[!] Vote?? ')

    if (pilihan == 1) {
        console.log()
        const cookie = readlineSync.question('[!] Cookie : ')
        const arrayPush = detect.push({
            cookieAccount: cookie,
        });
        const testlistJson = JSON.stringify(detect);
        fs.unlinkSync(`loginWarpcast.json`)

        fs.appendFileSync(`loginWarpcast.json`, testlistJson);
        console.log(chalk.green('    Successfully input cookie'))
    } else if (pilihan == 2) {
        console.log()
        var nomor = readlineSync.question("[+] Akun Number : ");
        const deletez = delete detect[nomor]
        var hasil = detect.filter(function (a) {
            return typeof a !== 'undefined';
        });
        const testlistJson = JSON.stringify(hasil);
        fs.unlinkSync('loginWarpcast.json')

        fs.appendFileSync("loginWarpcast.json", testlistJson);
        console.log(chalk.white('[') + chalk.green(`!`) + chalk.white(']') + ` Information  => ` + chalk.yellow(`Successfully Delete Account`))
    } else if (pilihan == 3) {
        console.log()
        const username = readlineSync.question('[+] Username : ')
        console.log()
        const checking = await checkingUsername(username)
        const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
        const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
        const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
        const jsonparse = JSON.parse(jsonReplace)
        const userId = jsonparse.props.pageProps.user.fid;
        const followerCount = jsonparse.props.pageProps.user.followerCount;
        const followingCount = jsonparse.props.pageProps.user.followingCount;

        console.log(chalk.white('[') + chalk.green('!') + chalk.white(']'), `Successfully getting username ${username}`)
        console.log(`    FID / User ID   : ` + chalk.green(`${userId}`))
        console.log(`    Follower count  : ` + chalk.green(`${followerCount}`))
        console.log(`    Following count : ` + chalk.green(`${followingCount}`))
    } else if (pilihan == 4) {
        console.log()
        var setAkun = readlineSync.question("[+] Akun Number    : ");
        const username = readlineSync.question('[+] Username : ')
        console.log()
        const checking = await checkingUsername(username)
        const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
        const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
        const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
        const jsonparse = JSON.parse(jsonReplace)
        const userId = jsonparse.props.pageProps.user.fid;
        const followerCount = jsonparse.props.pageProps.user.followerCount;
        const followingCount = jsonparse.props.pageProps.user.followingCount;
        var cookie = detect[setAkun].cookieAccount;
        console.log()
        let check = await checkFollowing(cookie, userId)

        const result = check.result.users;
        console.log(chalk.green(`    Waiting Getting Check ${result.length}`))
        for (let index = 0; index < result.length; index++) {
            var usernameTarget = result[index].username;
            var userIdTarget = result[index].fid;
            var displayName = result[index].displayName;
            var followerCountTarget = result[index].followerCount;
            var followingCountTarget = result[index].followingCount;

            console.log(chalk.white('[') + chalk.green(`${index+1}/${result.length}` + chalk.white(']'), `Username    : ${usernameTarget}`))
            console.log(chalk.yellow(`    User Id         : ${userIdTarget}`))
            console.log(chalk.yellow(`    Display Name    : ${displayName}`))
            console.log(chalk.yellow(`    Follower Count  : ${followerCountTarget}`))
            console.log(chalk.yellow(`    Following Count : ${followingCountTarget}`))

            try {
                var followAccount = await follow(cookie, userIdTarget);
                var status = followAccount.result.success;
                console.log(chalk.yellow(`    Status Follow   : ` + chalk.green(`Success => ${status}`)))
            } catch (err) {
                console.log(chalk.yellow(`    Status Follow  : ` + chalk.red(`Failure`)))

            }

            if (index === 99) {
                const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                await new Promise(resolve => setTimeout(resolve, delay * 1000));
            } else if (index === 199) {
                const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                await new Promise(resolve => setTimeout(resolve, delay * 1000));
            } else if (index === 299) {
                const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                await new Promise(resolve => setTimeout(resolve, delay * 1000));
            } else if (index === 399) {
                const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                await new Promise(resolve => setTimeout(resolve, delay * 1000));
            } else if (index === 499) {
                const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                await new Promise(resolve => setTimeout(resolve, delay * 1000));
            }
        }

        try {
            console.log();
            let cursor = check.next.cursor;
            console.log(chalk.blue(`    Successfully getting Cursor : ` + chalk.yellow(`${cursor}`)));

            while (cursor) {
                const nextCheck = await checkFollowingCursor(cookie, userId, cursor);
                const nextResult = nextCheck.result.users;

                for (let index = 0; index < nextResult.length; index++) {
                    var usernameTarget = nextResult[index].username;
                    var userIdTarget = nextResult[index].fid;
                    var displayName = nextResult[index].displayName;
                    var followerCountTarget = nextResult[index].followerCount;
                    var followingCountTarget = nextResult[index].followingCount;

                    console.log(chalk.white('[') + chalk.green(`${index+1}/${result.length}` + chalk.white(']'), `Username    : ${usernameTarget}`))
                    console.log(chalk.yellow(`    User Id         : ${userIdTarget}`))
                    console.log(chalk.yellow(`    Display Name    : ${displayName}`))
                    console.log(chalk.yellow(`    Follower Count  : ${followerCountTarget}`))
                    console.log(chalk.yellow(`    Following Count : ${followingCountTarget}`))
                    var followAccount = await follow(cookie, userIdTarget);
                    try {
                        var status = followAccount.result.success;
                        console.log(chalk.yellow(`    Status Follow   : ` + chalk.green(`Success => ${status}`)))
                    } catch (err) {
                        console.log(chalk.yellow(`    Status Follow  : ` + chalk.red(`Failure`)))

                    }
                    if (index === 99) {
                        const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                        console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                        await new Promise(resolve => setTimeout(resolve, delay * 1000));
                    } else if (index === 199) {
                        const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                        console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                        await new Promise(resolve => setTimeout(resolve, delay * 1000));
                    } else if (index === 299) {
                        const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                        console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                        await new Promise(resolve => setTimeout(resolve, delay * 1000));
                    } else if (index === 399) {
                        const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                        console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                        await new Promise(resolve => setTimeout(resolve, delay * 1000));
                    } else if (index === 499) {
                        const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                        console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                        await new Promise(resolve => setTimeout(resolve, delay * 1000));
                    }
                }

                // Perbarui nilai cursor untuk iterasi selanjutnya
                cursor = nextCheck.next.cursor;
                console.log(chalk.blue(`    Successfully getting Next Cursor : ` + chalk.yellow(`${cursor}`)));

                // Jeda mungkin diperlukan di sini agar tidak membebani server terlalu banyak
                // Tergantung pada kebutuhan Anda dan kebijakan API yang Anda gunakan

                // Perbarui nilai check dengan nilai dari panggilan selanjutnya
                check = nextCheck;
            }
        } catch (err) {
            console.log()
            console.log(chalk.red('Clear Task...'))
        }
    } else if (pilihan == 5) {
        console.log()
        var setAkun = readlineSync.question("[+] Akun Number    : ");
        console.log()
        var cookie = detect[setAkun].cookieAccount;
        const profileCheck = await profile(cookie);
        try {
            var username = profileCheck.result.state.user.username;
            console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
            console.log()
            const checking = await checkingUsername(username)
            const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
            const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
            const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
            const jsonparse = JSON.parse(jsonReplace)
            const userId = jsonparse.props.pageProps.user.fid;
            const followerCount = jsonparse.props.pageProps.user.followerCount;
            const followingCount = jsonparse.props.pageProps.user.followingCount;
        } catch (err) {

        }
        console.log()
        let check = await checkFollowing(cookie, userId)

        const result = check.result.users;
        console.log(chalk.green(`    Waiting Getting Check ${result.length}`))
        for (let index = 0; index < result.length; index++) {
            var usernameTarget = result[index].username;
            var userIdTarget = result[index].fid;
            var displayName = result[index].displayName;
            var followerCountTarget = result[index].followerCount;
            var followingCountTarget = result[index].followingCount;

            console.log(chalk.white('[') + chalk.green(`${index+1}/${result.length}` + chalk.white(']'), `Username    : ${usernameTarget}`))
            console.log(chalk.yellow(`    User Id         : ${userIdTarget}`))
            console.log(chalk.yellow(`    Display Name    : ${displayName}`))
            console.log(chalk.yellow(`    Follower Count  : ${followerCountTarget}`))
            console.log(chalk.yellow(`    Following Count : ${followingCountTarget}`))

            var followAccount = await unFollow(cookie, userIdTarget);
            var status = followAccount.result.success;
            console.log(chalk.yellow(`    Status Unfollow   : ` + chalk.green(`Success => ${status}`)))
        }

        try {
            console.log();
            let cursor = check.next.cursor;
            console.log(chalk.blue(`    Successfully getting Cursor : ` + chalk.yellow(`${cursor}`)));

            while (cursor) {
                const nextCheck = await checkFollowingCursor(cookie, userId, cursor);
                const nextResult = nextCheck.result.users;

                for (let index = 0; index < nextResult.length; index++) {
                    var usernameTarget = nextResult[index].username;
                    var userIdTarget = nextResult[index].fid;
                    var displayName = nextResult[index].displayName;
                    var followerCountTarget = nextResult[index].followerCount;
                    var followingCountTarget = nextResult[index].followingCount;

                    console.log(chalk.white('[') + chalk.green(`${index+1}/${result.length}` + chalk.white(']'), `Username    : ${usernameTarget}`))
                    console.log(chalk.yellow(`    User Id         : ${userIdTarget}`))
                    console.log(chalk.yellow(`    Display Name    : ${displayName}`))
                    console.log(chalk.yellow(`    Follower Count  : ${followerCountTarget}`))
                    console.log(chalk.yellow(`    Following Count : ${followingCountTarget}`))
                    var followAccount = await unFollow(cookie, userIdTarget);
                    var status = followAccount.result.success;
                    console.log(chalk.yellow(`    Status Unfollow   : ` + chalk.green(`Success => ${status}`)))
                }

                // Perbarui nilai cursor untuk iterasi selanjutnya
                cursor = nextCheck.next.cursor;
                console.log(chalk.blue(`    Successfully getting Next Cursor : ` + chalk.yellow(`${cursor}`)));

                // Jeda mungkin diperlukan di sini agar tidak membebani server terlalu banyak
                // Tergantung pada kebutuhan Anda dan kebijakan API yang Anda gunakan

                // Perbarui nilai check dengan nilai dari panggilan selanjutnya
                check = nextCheck;
            }
        } catch (err) {
            console.log()
            console.log(chalk.red('Clear Task...'))
        }
    } else if (pilihan == 6) {
        console.log()
        var setAkun = readlineSync.question("[+] Akun Number           : ");
        var needComment = readlineSync.question("[+] Need Coment [ y / n ] : ")
        if (needComment.toLowerCase() == "y") {
            var Comment = readlineSync.question("[+] Comment        : ");
        }
        console.log()
        var cookie = detect[setAkun].cookieAccount;
        const profileCheck = await profile(cookie);
        try {
            var username = profileCheck.result.state.user.username;
            console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
            console.log()
            const checking = await checkingUsername(username)
            const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
            const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
            const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
            const jsonparse = JSON.parse(jsonReplace)
            const userId = jsonparse.props.pageProps.user.fid;
            const followerCount = jsonparse.props.pageProps.user.followerCount;
            const followingCount = jsonparse.props.pageProps.user.followingCount;
        } catch (err) {

        }
        console.log()
        const checkingCast = await checkCast(cookie);
        const result = checkingCast.result.casts

        for (let index = 0; index < result.length; index++) {
            const threadhash = result[index].hash;
            const author = result[index].author.username;
            const displayName = result[index].author.displayName;
            const userId = result[index].author.fid;
            const text = result[index].text;
            try {
                var opengraph = result[index].embeds.urls[0].openGraph.url;
            } catch (err) {

            }

            console.log(chalk.white(`[`) + chalk.green(`${index}/${result.length}`) + chalk.white(`]`) + chalk.blue(` Successfully getting thread hash : ` + chalk.yellow(`${threadhash}`)));
            console.log(chalk.yellow(`    Author         : ${author}`))
            console.log(chalk.yellow(`    Display Name   : ${displayName}`))
            console.log(chalk.yellow(`    User ID        : ${userId}`))
            console.log(chalk.yellow(`    Status Text    : ` + chalk.magenta(`${text}`)))

            awal: while (true) {
                try {
                    var followAccount = await follow(cookie, userId);
                    try {
                        var status = followAccount.result.success;
                        console.log(chalk.yellow(`    Status Follow  : ` + chalk.green(`Success => ${status}`)))
                    } catch (err) {
                        console.log(chalk.yellow(`    Status Follow  : ` + chalk.red(`Failure`)))

                    }
                    break;
                } catch (err) {
                    break;
                }
            }

            var likesStatus = await likes(cookie, threadhash)
            try {
                var statuslike = likesStatus.result.like.type;
                console.log(chalk.yellow(`    Status Like    : ` + chalk.green(`Success => ${statuslike}`)))
            } catch (err) {
                console.log(chalk.yellow(`    Status Like    : ` + chalk.red(`Failure`)))
            }
            var recastStatus = await recasts(cookie, threadhash)
            try {
                var statuslike = recastStatus.result;
                console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
            } catch (err) {
                console.log(chalk.yellow(`    Status Recast  : ` + chalk.red(`Failure`)))

            }
            if (opengraph == undefined) {
                console.log(chalk.yellow(`    Status Mint    : ` + chalk.red(`Not detected mint`)))
            } else {
                var mintWarp = await mintingBro(cookie, threadhash, opengraph)
                if (mintWarp.errors) {
                    console.log(chalk.yellow(`    Message Error  : `) + chalk.red(mintWarp.errors[0].message))
                } else if (mintWarp.result.success == true) {
                    console.log(chalk.yellow(`    Status Mint    : `) + chalk.green(mintWarp.result.success))
                } else {}
            }
            console.log()

            if (needComment.toLowerCase() == "y") {
                const commentKu = await commentBro(cookie, threadhash, Comment)
                console.log(chalk.yellow(`    Status Comment : `) + chalk.green(`Success`))
            }
        }
    } else if (pilihan == 7) {
        console.log()
        var setAkun = readlineSync.question("[+] Akun Number    : ");
        console.log()
        var cookie = detect[setAkun].cookieAccount;
        const profileCheck = await profile(cookie);
        try {
            var username = profileCheck.result.state.user.username;
            console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
            console.log()

            const checkingmyaccount = await checkingUsername(username)
            const matchingJsonmyaccount = checkingmyaccount.match('type="application/json">(.*)</script>')[0]
            const jsonStringWithoutHTMLTagsmyaccount = matchingJsonmyaccount.replace(/<\/?script[^>]*>/g, '');
            const jsonReplacemyaccount = jsonStringWithoutHTMLTagsmyaccount.replace('type="application/json">', '')
            const jsonparsemyaccount = JSON.parse(jsonReplacemyaccount)
            var usernameCheckingmyaccount = jsonparsemyaccount.query.username;
            var userIdmyaccount = jsonparsemyaccount.props.pageProps.user.fid;
            var followerCountmyaccount = jsonparsemyaccount.props.pageProps.user.followerCount;
            const followingCountmyaccount = jsonparsemyaccount.props.pageProps.user.followingCount;


            const checking = await checkingUsername(usernameTarget)
            const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
            const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
            const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
            const jsonparse = JSON.parse(jsonReplace)
            var usernameChecking = jsonparse.query.username;
            var userId = jsonparse.props.pageProps.user.fid;
            var followerCount = jsonparse.props.pageProps.user.followerCount;
            const followingCount = jsonparse.props.pageProps.user.followingCount;
        } catch (err) {

        }

        let check = await checkFollowing(cookie, userIdmyaccount)

        let result2 = check.result.users;
        console.log(chalk.green(`    Waiting Getting Check ${result2.length}`))
        for (let index = 0; index < result2.length; index++) {
            var usernameTarget = result2[index].username;
            var userIdTarget = result2[index].fid;
            var displayName = result2[index].displayName;
            var followerCountTarget = result2[index].followerCount;
            var followingCountTarget = result2[index].followingCount;

            console.log(chalk.white('[') + chalk.green(`${index+1}/${result2.length}` + chalk.white(']'), `Username    : ${usernameTarget}`))
            console.log(chalk.yellow(`    User Id         : ${userIdTarget}`))
            console.log(chalk.yellow(`    Display Name    : ${displayName}`))
            console.log(chalk.yellow(`    Follower Count  : ${followerCountTarget}`))
            console.log(chalk.yellow(`    Following Count : ${followingCountTarget}`))
            console.log()
            console.log(chalk.white(`[!] Waiting For Checking ` + chalk.yellow(`${usernameTarget} [ ` + chalk.green(`${userIdTarget}`) + chalk.yellow(` ]`))))
            console.log()
            let check = await checkFollowing(cookie, userIdTarget)
            const result = check.result.users;
            const resultStringify = JSON.stringify(result);
            if (resultStringify.match(username)) {
                console.log(chalk.white(`    ${usernameTarget} ` + chalk.green(`has following u`)))
            } else {
                console.log(chalk.white(`    ${usernameTarget} ` + chalk.red(`not following u`)))
                var followAccount = await unFollow(cookie, userIdTarget);
                var status = followAccount.result.success;
                console.log(chalk.yellow(`    Status Unfollow   : ` + chalk.green(`Success => ${status}`)))
                console.log()

                if (index === 99) {
                    const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                    console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                    await new Promise(resolve => setTimeout(resolve, delay * 1000));
                } else if (index === 199) {
                    const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                    console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                    await new Promise(resolve => setTimeout(resolve, delay * 1000));
                } else if (index === 299) {
                    const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                    console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                    await new Promise(resolve => setTimeout(resolve, delay * 1000));
                } else if (index === 399) {
                    const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                    console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                    await new Promise(resolve => setTimeout(resolve, delay * 1000));
                } else if (index === 499) {
                    const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                    console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                    await new Promise(resolve => setTimeout(resolve, delay * 1000));
                }
            }
        }

        try {
            console.log();
            let cursor = check.next.cursor;
            console.log(chalk.blue(`    Successfully getting Cursor : ` + chalk.yellow(`${cursor}`)));

            while (cursor) {
                const nextCheck = await checkFollowingCursor(cookie, userIdmyaccount, cursor);
                const nextResult = nextCheck.result.users;

                for (let index = 0; index < nextResult.length; index++) {
                    var usernameTarget = nextResult[index].username;
                    var userIdTarget = nextResult[index].fid;
                    var displayName = nextResult[index].displayName;
                    var followerCountTarget = nextResult[index].followerCount;
                    var followingCountTarget = nextResult[index].followingCount;

                    console.log(chalk.white('[') + chalk.green(`${index+1}/${result.length}` + chalk.white(']'), `Username    : ${usernameTarget}`))
                    console.log(chalk.yellow(`    User Id         : ${userIdTarget}`))
                    console.log(chalk.yellow(`    Display Name    : ${displayName}`))
                    console.log(chalk.yellow(`    Follower Count  : ${followerCountTarget}`))
                    console.log(chalk.yellow(`    Following Count : ${followingCountTarget}`))
                    console.log()
                    console.log(chalk.white(`[!] Waiting For Checking ` + chalk.yellow(`${usernameTarget} [ ` + chalk.green(`${userIdTarget}`) + chalk.yellow(` ]`))))
                    console.log()
                    let check = await checkFollowing(cookie, userIdTarget)
                    const result = check.result.users;
                    const resultStringify = JSON.stringify(result);
                    if (resultStringify.match(username)) {
                        console.log(chalk.white(`    ${usernameTarget} ` + chalk.green(`has following u`)))
                    } else {
                        console.log(chalk.white(`    ${usernameTarget} ` + chalk.red(`not following u`)))
                        var followAccount = await unFollow(cookie, userIdTarget);
                        var status = followAccount.result.success;
                        console.log(chalk.yellow(`    Status Unfollow   : ` + chalk.green(`Success => ${status}`)))
                        console.log()

                        if (index === 99) {
                            const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                            console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                            await new Promise(resolve => setTimeout(resolve, delay * 1000));
                        } else if (index === 199) {
                            const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                            console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                            await new Promise(resolve => setTimeout(resolve, delay * 1000));
                        } else if (index === 299) {
                            const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                            console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                            await new Promise(resolve => setTimeout(resolve, delay * 1000));
                        } else if (index === 399) {
                            const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                            console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                            await new Promise(resolve => setTimeout(resolve, delay * 1000));
                        } else if (index === 499) {
                            const delay = Math.floor(Math.random() * 51) + 10; // Random delay antara 10-60 detik
                            console.log(chalk.yellow(`    Waiting for ${delay} seconds...`));
                            await new Promise(resolve => setTimeout(resolve, delay * 1000));
                        }
                    }
                }

                // Perbarui nilai cursor untuk iterasi selanjutnya
                cursor = nextCheck.next.cursor;
                console.log(chalk.blue(`    Successfully getting Next Cursor : ` + chalk.yellow(`${cursor}`)));

                // Jeda mungkin diperlukan di sini agar tidak membebani server terlalu banyak
                // Tergantung pada kebutuhan Anda dan kebijakan API yang Anda gunakan

                // Perbarui nilai check dengan nilai dari panggilan selanjutnya
                check = nextCheck;
            }
        } catch (err) {
            console.log()
            console.log(chalk.red('Clear Task...'))
        }
    } else if (pilihan == 8) {
        var pilihan = readlineSync.question('[!] Username [ y / n ] : ')
        var recastgajing = readlineSync.question('[!] Recast [ y / n ]   : ')
        var delaySleep = readlineSync.question("[+] Pause Random Seconds [ 60 - 1200 ] : ");

        if (pilihan.toLowerCase() == "y") {
            var usernameTarget = readlineSync.question('[!] Username Target : ');
            console.log()
            for (let index2 = 0; index2 < detect.length; index2++) {
                var cookie = detect[index2].cookieAccount;
                console.log()

                var split = delaySleep.split('-');

                var min = parseFloat(split[0]);
                var max = parseFloat(split[1]);
                var dataDelay = randomDelay(min, max);

                console.log(chalk.white('[') + chalk.green('!') + chalk.white(']') + ` Information     => ` + chalk.yellow(` Has Set Up Delay ${dataDelay} Seconds`))

                const profileCheck = await profile(cookie);
                try {
                    var username = profileCheck.result.state.user.username;
                    console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
                    console.log()
                    const checking = await checkingUsername(username)
                    const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                    const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                    const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                    const jsonparse = JSON.parse(jsonReplace)
                    const userId = jsonparse.props.pageProps.user.fid;
                    const followerCount = jsonparse.props.pageProps.user.followerCount;
                    const followingCount = jsonparse.props.pageProps.user.followingCount;
                } catch (err) {

                }

                try {
                    const checking = await checkingUsername(usernameTarget)
                    const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                    const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                    const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                    const jsonparse = JSON.parse(jsonReplace)
                    var usernameChecking = jsonparse.query.username;
                    var userId = jsonparse.props.pageProps.user.fid;
                    var followerCount = jsonparse.props.pageProps.user.followerCount;
                    var followingCount = jsonparse.props.pageProps.user.followingCount;
                } catch (err) {
                    console.log(err)
                }

                console.log(chalk.yellow(`    Username Target : ` + chalk.green(usernameTarget)))
                console.log(chalk.yellow(`    Username ID     : ` + chalk.green(userId)))
                console.log(chalk.yellow(`    Follower        : ` + chalk.green(followerCount)))
                console.log(chalk.yellow(`    Following       : ` + chalk.green(followingCount)))

                const checkCasting = await checkCast2(cookie, userId);
                var checkingHash = checkCasting.result.casts;
                for (let index = 0; index < checkingHash.length; index++) {
                    try {
                        var threadhash = checkingHash[index].hash;
                        var timestamp = checkingHash[index].timestamp;
                        const timestampNow = Date.now();

                        const date1 = new Date(timestamp);
                        const date2 = new Date(timestampNow);

                        const isSameDate = date1.getDate() === date2.getDate() &&
                            date1.getMonth() === date2.getMonth() &&
                            date1.getFullYear() === date2.getFullYear();

                        if (isSameDate == true) {
                            console.log(chalk.yellow(`    Time Post       : ` + chalk.green(`${new Date(timestamp)}`)))
                            console.log(chalk.yellow(`[${index}] Thread Hash     : ` + chalk.green(`${threadhash}`)))
                            var likesStatus = await likes(cookie, threadhash)
                            try {
                                var statuslike = likesStatus.result.like.type;
                                console.log(chalk.yellow(`    Status Like    : ` + chalk.green(`Success => ${statuslike}`)))
                            } catch (err) {
                                console.log(chalk.yellow(`    Status Like    : ` + chalk.red(`Failure`)))
                            }

                            console.log(chalk.yellow(`    Status Like     : ` + chalk.green(`Success => ${statuslike}`)))
                            if (recastgajing.toLowerCase() == "y") {
                                var recastStatus = await recasts(cookie, threadhash)
                                try {
                                    var statuslike = recastStatus.result;
                                    console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
                                } catch (err) {
                                    console.log(chalk.yellow(`    Status Recast  : ` + chalk.red(`Failure`)))

                                }
                                console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
                            }
                            await delay(`${dataDelay}000`)
                        } else {
                            console.log(chalk.yellow(`[${index}] Thread Hash     : ` + chalk.green(`${threadhash}`)))
                            console.log(chalk.yellow(`    Time Post       : ` + chalk.green(`${new Date(timestamp)}`)))
                            console.log(chalk.yellow(`    Status Like     : ` + chalk.green(`Can't like this post, not same timestamp`)))
                        }
                        console.log()
                    } catch (err) {
                        console.log(err)
                    }
                }
            }
        } else if (pilihan.toLowerCase() == "n") {
            var urlTarget = readlineSync.question('[!] URL Target      : ');
            var usernameTarget = urlTarget.split('/')[3];
            var txhashTarget = urlTarget.split('/')[4];
            for (let index2 = 0; index2 < detect.length; index2++) {
                var cookie = detect[index2].cookieAccount;
                console.log()

                var split = delaySleep.split('-');

                var min = parseFloat(split[0]);
                var max = parseFloat(split[1]);
                var dataDelay = randomDelay(min, max);

                console.log(chalk.white('[') + chalk.green('!') + chalk.white(']') + ` Information     => ` + chalk.yellow(` Has Set Up Delay ${dataDelay} Seconds`))

                const profileCheck = await profile(cookie);
                try {
                    var username = profileCheck.result.state.user.username;
                    console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
                    console.log()
                    const checking = await checkingUsername(username)
                    const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                    const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                    const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                    const jsonparse = JSON.parse(jsonReplace)
                    const userId = jsonparse.props.pageProps.user.fid;
                    const followerCount = jsonparse.props.pageProps.user.followerCount;
                    const followingCount = jsonparse.props.pageProps.user.followingCount;
                } catch (err) {

                }

                try {
                    const checking = await checkingUsername(usernameTarget)
                    const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                    const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                    const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                    const jsonparse = JSON.parse(jsonReplace)
                    var usernameChecking = jsonparse.query.username;
                    var userId = jsonparse.props.pageProps.user.fid;
                    var followerCount = jsonparse.props.pageProps.user.followerCount;
                    var followingCount = jsonparse.props.pageProps.user.followingCount;
                } catch (err) {
                    console.log(err)
                }

                console.log(chalk.yellow(`    Username Target : ` + chalk.green(usernameTarget)))
                console.log(chalk.yellow(`    Username ID     : ` + chalk.green(userId)))
                console.log(chalk.yellow(`    Follower        : ` + chalk.green(followerCount)))
                console.log(chalk.yellow(`    Following       : ` + chalk.green(followingCount)))

                const checkingCastku = await checkCastTarget(cookie, usernameTarget, txhashTarget)
                var threadhash = checkingCastku.result.casts[1].hash
                try {
                    console.log(chalk.yellow(`    Thread Hash     : ` + chalk.green(`${threadhash}`)))
                    var likesStatus = await likes(cookie, threadhash)
                    try {
                        var statuslike = likesStatus.result.like.type;
                        console.log(chalk.yellow(`    Status Like    : ` + chalk.green(`Success => ${statuslike}`)))
                    } catch (err) {
                        console.log(chalk.yellow(`    Status Like    : ` + chalk.red(`Failure`)))
                    }
                    console.log(chalk.yellow(`    Status Like     : ` + chalk.green(`Success => ${statuslike}`)))
                    if (recastgajing.toLowerCase() == "y") {
                        var recastStatus = await recasts(cookie, threadhash)
                        try {
                            var statuslike = recastStatus.result;
                            console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
                        } catch (err) {
                            console.log(chalk.yellow(`    Status Recast  : ` + chalk.red(`Failure`)))

                        }
                        console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
                    }
                    await delay(`${dataDelay}000`)

                } catch (err) {
                    console.log(err)
                }
            }
        }
    } else if (pilihan == 9) {

        for (let index2 = 0; index2 < detect.length; index2++) {
            var cookie = detect[index2].cookieAccount;
            console.log()
            const profileCheck = await profile(cookie);
            try {
                var username = profileCheck.result.state.user.username;
                console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
                console.log()
                const checking = await checkingUsername(username)
                const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                const jsonparse = JSON.parse(jsonReplace)
                const userId = jsonparse.props.pageProps.user.fid;
                const followerCount = jsonparse.props.pageProps.user.followerCount;
                const followingCount = jsonparse.props.pageProps.user.followingCount;
            } catch (err) {

            }

            const checkingCaster = await checkChannelCaster(cookie)
            var usernameChannelLength = checkingCaster.result.channels;
            for (let index = 0; index < usernameChannelLength.length; index++) {
                var usernameChannel = usernameChannelLength[index].key
                console.log(chalk.yellow(`[${index}] Username channel     : ` + chalk.green(`${usernameChannel}`)))
                const foll = await followCaster(cookie, usernameChannel)
                if (foll.result.success == true) {
                    console.log(chalk.yellow(`    Status Follow        : ` + chalk.green(`Success`)))
                } else {
                    console.log(chalk.yellow(`    Status Follow        : ` + chalk.red(`Failure`)))

                }
            }
        }
    } else if (pilihan == 10) {

        var usernamechannel = readlineSync.question('[!] Username Channel Target : ');
        var pilihan = "y"
        var recastgajing = readlineSync.question('[!] Recast [ y / n ]   : ')
        var delaySleep = readlineSync.question("[+] Pause Random Seconds [ 60 - 1200 ] : ");

        if (pilihan.toLowerCase() == "y") {
            console.log()
            for (let index2 = 0; index2 < detect.length; index2++) {
                var cookie = detect[index2].cookieAccount;
                console.log()

                var split = delaySleep.split('-');

                var min = parseFloat(split[0]);
                var max = parseFloat(split[1]);
                var dataDelay = randomDelay(min, max);

                console.log(chalk.white('[') + chalk.green('!') + chalk.white(']') + ` Information     => ` + chalk.yellow(` Has Set Up Delay ${dataDelay} Seconds`))

                const profileCheck = await profile(cookie);
                try {
                    var username = profileCheck.result.state.user.username;
                    console.log(chalk.white(`[!] Succesfully login ` + chalk.yellow(`${username}`)))
                    console.log()
                    const checking = await checkingUsername(username)
                    const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                    const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                    const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                    const jsonparse = JSON.parse(jsonReplace)
                    const userId = jsonparse.props.pageProps.user.fid;
                    const followerCount = jsonparse.props.pageProps.user.followerCount;
                    const followingCount = jsonparse.props.pageProps.user.followingCount;
                } catch (err) {

                }

                while (true) {
                    const checkCasterChannel = await checkCastChannel(cookie, usernamechannel)
                    const result = checkCasterChannel.result.items
                    for (let index = 0; index < result.length; index++) {
                        var threadhash = result[index].cast.hash;
                        var author = result[index].cast.author.username;
                        var displayName = result[index].cast.author.displayName;
                        var userId = result[index].cast.author.fid;
                        var text = result[index].cast.text;
                        try {
                            var opengraph = result[index].embeds.urls[0].openGraph.url;
                        } catch (err) {

                        }
                        try {
                            const checking = await checkingUsername(author)
                            const matchingJson = checking.match('type="application/json">(.*)</script>')[0]
                            const jsonStringWithoutHTMLTags = matchingJson.replace(/<\/?script[^>]*>/g, '');
                            const jsonReplace = jsonStringWithoutHTMLTags.replace('type="application/json">', '')
                            const jsonparse = JSON.parse(jsonReplace)
                            var usernameChecking = jsonparse.query.username;
                            var userId = jsonparse.props.pageProps.user.fid;
                            var followerCount = jsonparse.props.pageProps.user.followerCount;
                            var followingCount = jsonparse.props.pageProps.user.followingCount;
                        } catch (err) {
                            console.log(err)
                        }

                        console.log(chalk.yellow(`[${index}/${result.length}] Username Target : ` + chalk.green(author)))
                        console.log(chalk.yellow(`    Username ID     : ` + chalk.green(userId)))
                        console.log(chalk.yellow(`    Follower        : ` + chalk.green(followerCount)))
                        console.log(chalk.yellow(`    Following       : ` + chalk.green(followingCount)))
                        console.log(chalk.yellow(`[${index}] Thread Hash     : ` + chalk.green(`${threadhash}`)))
                        var likesStatus = await likes(cookie, threadhash)
                        try {
                            var statuslike = likesStatus.result.like.type;
                            console.log(chalk.yellow(`    Status Like    : ` + chalk.green(`Success => ${statuslike}`)))
                        } catch (err) {
                            console.log(chalk.yellow(`    Status Like    : ` + chalk.red(`Failure`)))
                        }
                        console.log(chalk.yellow(`    Status Text    : ` + chalk.magenta(`${text}`)))
                        var followAccount = await follow(cookie, userId);
                        try {
                            var status = followAccount.result.success;
                            console.log(chalk.yellow(`    Status Follow  : ` + chalk.green(`Success => ${status}`)))
                        } catch (err) {
                            console.log(chalk.yellow(`    Status Follow  : ` + chalk.red(`Failure`)))

                        }
                        if (recastgajing.toLowerCase() == "y") {
                            var recastStatus = await recasts(cookie, threadhash)
                            try {
                                var statuslike = recastStatus.result;
                                console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
                            } catch (err) {
                                console.log(chalk.yellow(`    Status Recast  : ` + chalk.red(`Failure`)))

                            }
                            console.log(chalk.yellow(`    Status Recast  : ` + chalk.green(`Success => True`)))
                        }
                        await delay(`${dataDelay}000`)
                    }
                }
            }
        }
    }
    // var unfollowAccount = await unFollow(cookie, userId);
    // console.log(unfollowAccount);

    // var followAccount = await follow(cookie, userId);
    // console.log(followAccount)
})();


function randomDetik(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function licenseCheck(license) {
    var license = fetch(`https://whitelist-bot.com/api.php?license=${license}`, {
            "headers": {
                "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                "accept-language": "en-US,en;q=0.9",
                "sec-ch-ua": "\".Not/A)Brand\";v=\"99\", \"Google Chrome\";v=\"103\", \"Chromium\";v=\"103\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "document",
                "sec-fetch-mode": "navigate",
                "sec-fetch-site": "none",
                "sec-fetch-user": "?1",
                "upgrade-insecure-requests": "1",
                "cookie": "_ga=GA1.2.1441011143.1656930356"
            },
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": null,
            "method": "GET"
        })

        .then(async res => {
            const data = await res.json()
            return data
        })
    return license
}

function addMachine1(license, machine) {
    var license = fetch(`https://whitelist-bot.com/rahasiaku/editmachine.php?license=${license}`, {
        method: 'POST',
        headers: {
            'Host': 'whitelist-bot.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
            'Origin': 'https://whitelist-bot.com',
            'Referer': 'https://whitelist-bot.com/rahasiaku/',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-User': '?1',
            'Te': 'trailers'
        },
        body: new URLSearchParams({
            'MachineId1': machine
        })
    })
}

function addMachine2(license, machine) {
    var license = fetch(`https://whitelist-bot.com/rahasiaku/editmachine.php?license=${license}`, {
        method: 'POST',
        headers: {
            'Host': 'whitelist-bot.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
            'Origin': 'https://whitelist-bot.com',
            'Referer': 'https://whitelist-bot.com/rahasiaku/',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-User': '?1',
            'Te': 'trailers'
        },
        body: new URLSearchParams({
            'MachineId2': machine
        })
    })
}

function randomDelay(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}